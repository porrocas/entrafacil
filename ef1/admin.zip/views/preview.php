<div id="previsualizador" class="previsualizar-evento">
        <div class="cont-pre">
            <h1 id="preTitEvent">Titulo Evento</h1>
            <span id="preSloEvent">Slogan Evento</span>
            <div class="ubicacion-imagen">
                <div>
                    <img id="changeImage" src="publicidad-eventos/flayer/poster.jpg" alt="imagen de evento">
                </div>
            </div>
            <div class="latPrev">
                <span id="organizadorChange">Nombre organizador/es</span>
                <h1 id="numeroBolChange">Se venderán X boletas</h1>
                <h1 id="priceBol">Precio por boleta</h1>
                <div class="fechaYlugar">
                    <span id="preDiaEvent">Dia</span>
                    <span id="preMesEvent">Mes</span>
                    <span id="preAnoEvent">Año</span>   
                </div>
                <span id="preHoraEvent">Hora del evento</span>
                <br>
                <span id="preUbiEvent">Ubicación</span>
                <p id="preDesEvent">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ex in dolor debitis aspernatur ea, laudantium non at, quia ducimus aliquid, aperiam dicta amet iusto reiciendis neque dolore temporibus magni ab.</p>
                <br>
                <div class="cerrarPre">
                    <button onclick="cerrarPre()">Cerrar</button>
                </div>
            </div>
            
            
        </div>
    </div>