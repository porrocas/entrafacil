<section onclick="cerrarNav()" class="contPreTarifas">
    <div class="fondoPreTarifas">
    </div>

    <div class="tituloPreTarifas">
        <span>Entre mas sepas de nosotros, mejor sera nuestra relación.</span>
        <h1 class="fuenteCursiva">Conoce nuestros servicios y beneficios para ti!</h1>
    </div>

    <div class="contAstronauta floating">
        <img src="img/astronauta.png" alt="">
    </div>

    <div class="contInfoIndividuo">
        <div>
            <p>EntraFácil es aliado de los organizadores de eventos, por eso hemos dispuesto toda la información y canales de comunicación, para resolver tus dudas y ayudarte en lo que podamos.</p>
            <a href="tutorial.php" class="fuenteCursiva">Organizadores</a>
        </div>
        <div>
            <p>Para nosotros los asistentes a los eventos son nuestro motor, por eso siempre están en nuestras prioridades, resuelve tus dudas leyendo si no esta claro escríbenos.</p>
            <a href="soporte.php" class="fuenteCursiva">Asistentes</a>
        </div>
    </div>

    <div class="sloganPreTarifas">
        <p>El mejor aliado para toda clase de eventos, es EntraFácil.com</p>
    </div>
</section>