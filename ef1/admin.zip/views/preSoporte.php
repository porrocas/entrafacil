<article onclick="cerrarNav()" class="preSoporte">
    <div class="tituloSoporte">
        <span>Siempre Estamos Contigo</span>
        <h1 class="fuenteCursiva">Soporte y Contacto</h1>
    </div>
    <div class="imgSupports">
        <div>
            <div>
                <img src="img/chat.png" alt="soporte EntraFácil.com soporte técnico y ayuda en ventas">
            </div>
            <div>
                <p>Respuesta Inmediata</p>
            </div>
        </div>
        <div>
            <div>
                <img src="img/round.png" alt="soporte EntraFácil.com soporte técnico y ayuda en ventas">
            </div>
            <div>
                <p>Soporte 24/7</p>
            </div>
        </div>
        <div>
            <div>
                <img src="img/whatsap.png" alt="soporte EntrFácil.com soporte técnico y ayuda en ventas">
            </div>
            <div>
                <p>Chat en linea</p>
            </div>
        </div>
    </div>
    <div class="contFormSupport">
        <form action="#">
            <p>Si necesitas ayuda, dejanos tus datos pronto nos contactaremos.</p>
            <input type="text" placeholder="Nombre Completo">
            <input type="text" placeholder="Asunto">
            <input type="tel" placeholder="Whatsapp o numero de contacto">
            <input type="submit" value="Contactar">
        </form>
        <span>En nuestro pie de pagina de hay mas información de contacto, que puede de interesarte.</span>
    </div>
</article>