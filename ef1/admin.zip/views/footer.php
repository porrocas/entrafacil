<footer onclick="cerrarNav()">
    <div class="borderRight">
        <ul>
        <li class="contLogoFooter"><a href="#"><img src="img/logoWeb.png" alt="logo entrafácil comprar y vender entradas"></a></li>
        <li><a href="crear.php">Crear Evento</a></li>
        <li><a href="eventos.php">Buscar Eventos</a></li>
        <li><a href="eventos.php">Beneficios</a></li>
        <li><a href="#">Como Funciona</a></li>
        <li><a href="#">Preguntas Frecuentes</a></li>
        </ul>
    </div>
    <div class="borderRight">
        <ul>
        Acerca de:
        <li><a href="#">Quienes somos</a></li>
        <li><a href="#">Seguridad</a></li>
        <li><a href="#">Privacidad</a></li>
        <li><a href="#">Términos y condiciones</a></li>
        <li><a href="#">Protección cliente</a></li>
        <li><a href="#">Protección Organizador</a></li>
        </ul>
    </div>
    <div>
        <ul>
        Contacto:
        <li><a href="https://www.facebook.com/entra.facil.73">facebook</a></li>
        <li><a href="https://www.instagram.com/entrafacil/?hl=es-la">instagram</a></li>
        <li><a href="wa.me/573213915844">whatsapp</a></li>
        <li><a href="https://api.whatsapp.com/send?phone=573166989045&text=Hola,%20Desarrollador%20te%20necesito.">Soporte técnico</a></li>
        <li><a href="wa.me/573213915844">Soporte Ventas y eventos</a></li>
        </ul>
    </div>
    <section>
        <p> Desarrollador <a href="https://api.whatsapp.com/send?phone=573166989045&text=Hola,%20Desarrollador%20te%20necesito.">Daniel Mateus</a> © Todos los derechos reservados para EntraFácil.com | Con <span>❤</span> para LATAM.</p>
    </section>
</footer>